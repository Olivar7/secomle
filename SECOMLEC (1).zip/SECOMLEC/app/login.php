<?php

require 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $contraseña = $_POST['contraseña'];


    $hashContraseña = password_hash($contraseña, PASSWORD_DEFAULT);


    header('Location: http://localhost/SECOMLEC/cursos.html');
    exit();
}
?>
