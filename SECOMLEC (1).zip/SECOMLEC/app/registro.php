<?php
require 'conexion.php';
// Verificar si se ha enviado el formulario de registro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $contraseña = $_POST['contraseña'];
    // Validaciones
    $errores = array();

    if (!preg_match("/^[a-zA-Z0-9 ]+$/", $nombre)) {
        $errores[] = "<h1>El nombre no debe contener caracteres especiales</h1>";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo electrónico no es válido";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo electrónico no es válido";
    }
    if (strlen($nombre) < 3 || strlen($nombre) > 12) {
        $errores[] = "El nombre debe tener entre 3 y 12 caracteres";
    }

    // Validación de correo electrónico: Debe tener entre 10 y 30 caracteres
    if (strlen($email) < 10 || strlen($email) > 30) {
        $errores[] = "El correo electrónico debe tener entre 10 y 30 caracteres";
    }

    // Validación de contraseña: Debe tener entre 4 y 18 caracteres
    if (strlen($contraseña) < 4 || strlen($contraseña) > 18) {
        $errores[] = "La contraseña debe tener entre 4 y 18 caracteres";
    }
    // Si no hay errores, procede con el registro
    if (empty($errores)) {
        // Hashear la contraseña
        $hashContraseña = password_hash($contraseña, PASSWORD_DEFAULT);

        // Guardar los datos en la base de datos
        $stmt = $conn->prepare("INSERT INTO registro (nombre, email, contraseña) VALUES (?, ?, ?)");
        $stmt->execute([$nombre, $email, $hashContraseña]);

        // Redireccionar al formulario de inicio de sesión
        header('Location: login.html');
        exit();
    }
}

if (!empty($errores)) {
    echo "<div class='errores'>";
    foreach ($errores as $error) {
        echo "<p>$error </p>";
    }
    echo "</div>";
}
header('Location: index.html');

